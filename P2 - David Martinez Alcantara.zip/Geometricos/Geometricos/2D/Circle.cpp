
/* 
 * File:   Circle.cpp
 * Author: lidia
 * 
 * Created on 8 de febrero de 2021, 19:32
 */

#include "Circle.h"



	bool GEO::Circle::isInside (Point &p){
		
		//TODO
		return true;
	}


	GEO::Polygon GEO::Circle::getPointsCircle (){
		return Polygon();
	}
	
  
   