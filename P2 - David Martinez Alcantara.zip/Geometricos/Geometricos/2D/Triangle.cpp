#include "Triangle.h"

GEO::Triangle::Triangle(const Vec2D& aa, const Vec2D& bb, const Vec2D& cc): a(aa), b(bb), c(cc)
{
}

